image1 = 'E:\4.2\DIPLABASSM\assm1\priota1.jpg';
image2 = 'E:\4.2\DIPLABASSM\assm1\priota4.jpg';

img1=imread(image1);
img2=imread(image2);
A = 6;
B = 80;
C = A * B;
%image1 = imresize(img1, C, C);
%image2 = imresize(img2, C, C);
figure;
imshow(img1);
figure;
imshow(img2);
output = img1;
for i = 2 : 2 : A
    output(B * (i - 1) + 1 : B * i, :, :) = img2(B * (i - 1) + 1 : B * i,   :, :);
end
figure;
imshow(output);
imwrite(output, 'E:\4.2\DIPLABASSM\assm1\output.jpg');