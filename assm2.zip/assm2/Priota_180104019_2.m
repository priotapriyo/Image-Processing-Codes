R = imread('priota1.jpg');

R = rgb2gray(R);

if size(R, 3) == 3
    R = rgb2gray(R);
end
[row, col] = size(R);
J = de2bi(double(R));


S0 = reshape(J(:, 1), row, col);
S1 = reshape(J(:, 2), row, col);
S2 = reshape(J(:, 3), row, col);
S3 = reshape(J(:, 4), row, col);
S4 = reshape(J(:, 5), row, col);
S5 = reshape(J(:, 6), row, col);
S6 = reshape(J(:, 7), row, col);
S7 = reshape(J(:, 8), row, col);

X = ones(1, 8);
for i = 1 : 8
    X(i) = 2 ^ (i - 1);
end

S = ones(8, row, col);
for k = 1 : 8
    for i = 1 : row
        for j = 1: col
            S(k,i, j) = bitand(R(i, j), X(k));
        end
    end
end
figure
for k = 1 : 8
    subplot(2, 4, k);
    imshow(squeeze(S(k,:,:))); title([num2str(k) 'No Bit Plane']);
end