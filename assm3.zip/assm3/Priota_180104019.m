%Read an Image
a = imread('priota1.jpg');
Img=rgb2gray(a);
imshow(a);

figure,imshow(Img);

I = double(Img);

%Design the Gaussian Kernel

prompt='Enter the sigma value:';
sigma=input(prompt);

%Window size(11X11 matrix)
sz = 11;
[x,y]=meshgrid(-sz:sz,-sz:sz);

M = size(x,1)-1;
N = size(y,1)-1;
Exp_comp = -(x.^2+y.^2)/(2*sigma*sigma);
Kernel= exp(Exp_comp)/(2*pi*sigma*sigma);

%Initialize
Output=zeros(size(I));
%Pad the vector with zeros
I = padarray(I,[sz sz]);

%Convolution
for i = 1:size(I,1)-M
    for j =1:size(I,2)-N
        Temp = I(i:i+M,j:j+M).*Kernel;
        Output(i,j)=sum(Temp(:));
    end
end

Output = uint8(Output);
figure,imshow(Output);

title('Modified Image');
imwrite(Output,'E:\4.2\DIPLABASSM\assm3\output.jpg');
imshow(Output);